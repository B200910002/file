use humanresourcesmanagement;

drop table if exists ajiltan_log;
create table ajiltan_log 
(
	a_log_id integer not null auto_increment primary key,
    a_id integer not null,
    new_utas varchar(100),
    old_utas varchar(100),
    a_status varchar(100) not null
);

----------------------------------------------- utas insert trigger -------------------------------------------
drop trigger if exists before_ajiltan_insert;
delimiter //
create trigger after_ajiltan_insert
after insert on ajiltan
for each row begin
	insert into ajiltan_log
    set a_id=new.ajiltan_code,old_utas=null,new_utas=new.utas,a_status='insert';
end;
// delimiter ;

insert into ajiltan values (null, 'TestOvog', 'TestNer', 'm', '99111210', 'jk11223344', 'testUsername', 'testNuutsug',4);
show create trigger after_ajiltan_insert;
select * from ajiltan_log;
select *from ajiltan;

----------------------------------------------- utas update trigger -------------------------------------------
drop trigger if exists before_ajiltan_update;
delimiter //
create trigger before_ajiltan_update
before update on ajiltan
for each row begin
	insert into ajiltan_log
    set a_id=old.ajiltan_code,old_utas=old.utas,new_utas=new.utas,a_status='update';
end;
// delimiter ;

update ajiltan set utas = '11223344' where ajiltan_code = 11;
show create trigger before_ajiltan_update;
select * from ajiltan_log;
select *from ajiltan;

----------------------------------------------- utas delete trigger -------------------------------------------
drop trigger if exists after_ajiltan_delete;
delimiter //
create trigger after_ajiltan_delete
after delete on ajiltan
for each row begin
	insert into ajiltan_log
    set a_id=old.ajiltan_code,old_utas=old.utas,new_utas=null,a_status='delete';
end;
// delimiter ;

delete from ajiltan where ajiltan_code = 11;
show create trigger after_ajiltan_delete;
select * from ajiltan_log;
select *from ajiltan;