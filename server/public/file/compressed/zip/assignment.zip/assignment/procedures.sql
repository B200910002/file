use humanresourcesmanagement;

-- utas procedures 
delimiter //
create procedure insertUtas(in utas varchar(8), in acode int) begin 
	insert into utas values(null, utas, acode);
end;
create procedure updateUtas(in ucode int, in phone varchar(8), in acode int) begin
	update utas set utas = phone,ajiltan_code = acode where utas_code = ucode;
end;
create procedure deleteUtas(in ucode int) begin
	delete from utas where utas_code = ucode;
end;
// delimiter ;
-- =================================================================================================================== 
select * from utas;
desc utas;
call insertUtas('99999999', 1);
call updateUtas(21, '11111111', 2);
call deleteUtas(21);

-- ajiltan angilal procedures
delimiter //
create procedure insertAjiltanAngilal(in ner varchar(45)) begin
	insert into ajiltanangilal values (null, ner);
end;
create procedure updateAjiltanAngilal(in acode int, in ner varchar(45)) begin 
	update ajiltanangilal set angilal_ner = ner where ajiltan_angilal_code = acode;
end;
create procedure deleteAjiltanAngilal(in acode int) begin 
	delete from ajiltanangilal where ajiltan_angilal_code = acode; 
end;
// delimiter ;
-- =================================================================================================================== 
select * from ajiltanangilal;
desc ajiltanangilal;
call insertAjiltanAngilal('test');
call updateAjiltanAngilal(11, 'testAniglal');
call deleteAjiltanAngilal(11);

-- ajiltan procedures
delimiter //
create procedure insertAjiltan(in lastname varchar(255), in firstname varchar(255), in gender varchar(2), in phone varchar(8), in register varchar(10), in username varchar(40), in pass varchar(16), in angilal int) begin 
	insert into ajiltan values(null,lastname, firstname, gender, phone, register, username, pass, angilal);
end;
create procedure updateAjiltan(in acode int, in lastname varchar(255), in firstname varchar(255), in gender varchar(2), in phone varchar(8), in register varchar(10), in username varchar(40), in pass varchar(16), in angilal int) begin
	update ajiltan set ovog=lastname,ner=firstname,huis=gender,utas=phone,register_dugaar=register,nevtreh_ner=username,nuuts_ug=pass,angilal_code=angilal where ajiltan_code=acode;
end;
create procedure deleteAjiltan(in acode int) begin
	delete from ajiltan where ajiltan_code = acode;
end; 
// delimiter ; 
-- =================================================================================================================== 
select * from ajiltan;
desc ajiltan;
call insertAjiltan('testovog','testNer','M','11111111','ts11111111','testUsername','testPassword',1);
call updateAjiltan(11,'tes2tovog','test2Ner','FM','22222222','ts22222222','test2Username','test2Password',2);
call deleteAjiltan(11);

-- hotaimgiinlavlah procedures
delimiter //
create procedure insertHotaimgiinlavlah(in hcode varchar(2),in hotner varchar(45)) begin
	insert into hotaimgiinlavlah values(hcode, hotner);
end;
create procedure updateHotaimgiinlavlah(in hcode varchar(2), in hotner varchar(45)) begin
	update hotaimgiinlavlah set hot_aimgiin_ner = hotner where hot_aimgiin_lavlah_code = hcode;
end;
create procedure deleteHotaimgiinlavlah(in hcode varchar(2)) begin
	delete from hotaimgiinlavlah where hot_aimgiin_lavlah_code = hcode;
end;
// delimiter ;
-- =================================================================================================================== 
select * from hotaimgiinlavlah;
desc hotaimgiinlavlah;
call inserthotaimgiinlavlah('tt','testHot');
call updateHotaimgiinlavlah('tt','test');
call deletehotaimgiinlavlah('tt');


-- duureg sumiin lavlah
delimiter //
create procedure insertDuuregsumiinlavlah(in dcode varchar(3), in dner varchar(45), in hcode varchar(2)) begin 
	insert into duuregsumiinlavlah values(dcode, dner, hcode);
end;
create procedure updateDuuregsumiinlavlah(in dcode varchar(3), in dner varchar(45), in hcode varchar(2)) begin 
	update duuregsumiinlavlah set duureg_sumiin_lavlah_ner = dner, hot_aimgiin_lavlah_code = hcode where duureg_sumiin_lavlah_code = dcode;
end;
create procedure deleteDuuregsumiinlavlah(in dcode varchar(3)) begin
	delete from duuregsumiinlavlah where duureg_sumiin_lavlah_code = dcode;
end;
//delimiter ;
-- ===================================================================================================================  
select * from duuregsumiinlavlah;
desc duuregsumiinlavlah;
call insertDuuregsumiinlavlah('tst','testDuureg','УБ');
call updateduuregsumiinlavlah('tst','test2','УБ');
call deleteduuregsumiinlavlah('tst');

-- horoo lavlah
delimiter //
create procedure insertHoroolavlah(in hner varchar(45), in dcode varchar(3)) begin
	insert into horoolavlah values(null, hner, dcode);
end;
create procedure updateHoroolavlah(in horcode int, in hner varchar(45), in dcode varchar(3)) begin
	update horoolavlah set horoo_ner = hner, duureg_sumiin_lavlah_code = dcode where horoo_lavlah_code = horcode;
end;
create procedure deleteHoroolavlah(in horcode int) begin
	delete from horoolavlah where horoo_lavlah_code = horcode;
end;
//delimiter ;
-- ===================================================================================================================  
select * from horoolavlah;
desc horoolavlah;
call inserthoroolavlah('test','БЗД');
call updatehoroolavlah(12,'test','ДАС');
call deletehoroolavlah(12);

-- geriinhayg
delimiter //
create procedure insertgeriinhayag(in del varchar(45), in d date, in acode int, in hcode int) begin 
	insert into geriinhayag values(null, del, d, acode, hcode);
end;
create procedure updategeriinhayag(in gcode int, in del varchar(45), in d date, in acode int, in hcode int) begin
	update geriinhayag set geriin_hayag = del, ognoo = d, ajiltan_code = acode, horoo_lavlah_code = hcode where geriin_hayag_code = gcode;
end;
create procedure deletegeriinhayag(in gcode int) begin 
	delete from geriinhayag where geriin_hayag_code = gcode;
end;
// delimiter ;
-- ===================================================================================================================  
select * from geriinhayag;
desc geriinhayag;
call insertgeriinhayag('test',now(), 1,11);
call updategeriinhayag(11,'test2',now(),2,1);
call deletegeriinhayag(11);

-- albantushaal lavlah
delimiter //
create procedure insertAlbantushaalLavlah(in ner varchar(45)) begin
	insert into albantushaallavlah values(null, ner);
end;
create procedure updateAlbantushaallavlah(in code int, in ner varchar(45)) begin
	update albantushaallavlah set alban_tushaal_ner = ner where alban_tushaal_lavlah_code=code; 
end;
create procedure deleteAlbanTushaallavlah(in code int)begin
	delete from albantushaallavlah where alban_tushaal_lavlah_code = code;
end;
// delimiter ;
-- ===================================================================================================================  
select * from albantushaallavlah;
desc albantushaallavlah;
call insertalbantushaallavlah('test1');
call updatealbantushaallavlah(12,'test2');
call deletealbantushaallavlah(12);


-- albantushaal
delimiter //
create procedure insertAlbantushaal(in sd date, in ed date, in acode int, albacode int) begin
	insert into albantushaal values(null, sd, ed, acode, albacode);
end;
create procedure updateAlbantushaal(in code int, in sd date, in ed date, in acode int, in albacode int)begin
	update albantushaal set ajild_orson_ognoo=sd, ajlaas_garsan_ognoo=ed, ajiltan_code=acode, alban_tushaal_lavlah_code=albacode where alban_tushaal_code = code;
end;
create procedure deleteAlbantushaal(in code int) begin
	delete from albantushaal where alban_tushaal_code = code;
end;
// delimiter ;
-- ===================================================================================================================  
select * from albantushaal;
desc albantushaal;
call insertalbantushaal('2012-12-1',now(),1,1);
call updatealbantushaal(11,'2000-1-1',now(),2,2);
call deletealbantushaal(11);

-- eruulmend lavlah
delimiter //
create procedure inserteruulmendlavlah(in ner varchar(45)) begin
	insert into eruulmendlavlah values(null, ner);
end;
create procedure updateeruulmendLavlah(in code int, in ner varchar(45)) begin
	update eruulmendlavlah set eruul_mend_lavlah_ner = ner where eruul_mend_lavlah_code=code;
end;
create procedure deleteeruulmendlavlah(in code int) begin
	delete from eruulmendlavlah where eruul_mend_lavlah_code = code;
end;
// delimiter ;
select * from eruulmendlavlah;
desc eruulmendlavlah;
call inserteruulmendlavlah('test1');
call updateeruulmendlavlah(11,'test2');
call deleteeruulmendlavlah(11);

-- eruulmend
delimiter //
create procedure inserteruulmend(in d date, in acode int, in ecode int) begin 
	insert into eruulmend values(null, d, acode, ecode);
end;
create procedure updateeruulmend(in code int, in d date, in acode int, in ecode int)begin
	update eruulmend set ehleh_ognoo=d, ajiltan_code=acode, eruul_mend_lavlah_code=ecode where eruul_mend_code=code;
end;
create procedure deleteeruulmend(in code int) begin
	delete from eruulmend where eruul_mend_code=code;
end;
// delimiter ;
select * from eruulmend;
desc eruulmend;
call inserteruulmend('2000-1-1',1,6);
call updateeruulmend(11,now(),1,5);
call deleteeruulmend(11);









-------------------------------------------- uramshuulal procedures -----------------------------------------------------
delimiter //
create procedure insertUramshuulal(in u_mungun_dun int, in u_ognoo date, in acode int, in ulcode int) begin 
	insert into uramshuulal values(null, u_mungun_dun, u_ognoo, acode, ulcode);
end;

create procedure updateUramshuulal(in ucode int, in u_mungun_dun int, in u_ognoo date, in acode int, in ulcode int) begin
	update uramshuulal set mungun_dun = u_mungun_dun, ognoo = u_ognoo, ajiltan_code = acode, uramshuulal_lavlah_code = ulcode where uramshuulal_code = ucode;
end;

create procedure deleteUramshuulal(in ucode int) begin
	delete from uramshuulal where uramshuulal_code = ucode;
end;
// delimiter ;

select * from uramshuulal;
desc uramshuulal;
call insertUramshuulal('439000',now(), 1, 10);
call updateUramshuulal(11, '299000', now(), 1, 10);
call deleteUramshuulal(11);



-------------------------------------------- uramshuulalLavlah procedures -----------------------------------------------------

delimiter //
create procedure insertUramshuulalLavlah(in ulner varchar(45)) begin 
	insert into uramshuulalLavlah values(null, ulner);
end;

create procedure updateUramshuulalLavlah(in ulcode int, in ulner varchar(45)) begin
	update uramshuulalLavlah set uramshuulal_lavlah_ner = ulner where uramshuulal_lavlah_code  = ulcode;
end;

create procedure deleteUramshuulalLavlah(in ulcode int) begin
	delete from uramshuulalLavlah where uramshuulal_lavlah_code  = ulcode;
end;
// delimiter ;
select * from uramshuulalLavlah;
desc uramshuulalLavlah;
call insertUramshuulalLavlah('Шилдэг ажилтан');
call updateUramshuulalLavlah(11, 'Шилдэг эмэгтэй ажилтан');
call deleteUramshuulalLavlah(11);


-------------------------------------------- gerbullavlah procedures -----------------------------------------------------
delimiter //
create procedure insertgerbullavlah(in ger_bul_lavlah_ner varchar(45)) begin
    insert into gerbullavlah values(null, ger_bul_lavlah_ner);
end;

create procedure updategerbullavlah(in gerbullavlahcode int, in gerbullavlahner varchar(45)) begin
	update gerbullavlah set ger_bul_lavlah_ner = gerbullavlahner where ger_bul_lavlah_code = gerbullavlahcode;
end;

create procedure deletegerbullavlah(in gerbullavlahcode int) begin
	delete from gerbullavlah where ger_bul_lavlah_code = gerbullavlahcode;
end;
// delimiter ;

select * from gerbullavlah;
desc gerbullavlah;
call insertgerbullavlah('Unenkhuu');
call updategerbullavlah(11, 'Batsukh');
call deletegerbullavlah(11);
-------------------------------------------- gerbul procedures -----------------------------------------------------
delimiter //
create procedure insertgerbul(in ger_bul_ner varchar(45), in ajiltan_code int, in ger_bul_lavlah_code int, in undes_ugsaa varchar(45)) begin
	insert into gerbul values(null, ger_bul_ner, ajiltan_code, ger_bul_lavlah_code, undes_ugsaa);
end;

create procedure updategerbul(in gerbulcode int, in gerbulner varchar(45), in ajiltancode int, in gerbullavlahcode int, in undesugsaa varchar(45)) begin
	update gerbul set ger_bul_ner = gerbulner, ajiltan_code = ajiltancode, ger_bul_lavlah_code = gerbullavlahcode, undes_ugsaa = undesugsaa where ger_bul_code = gerbulcode;
end;

create procedure deletegerbul(in gerbulcode int) begin
	delete from gerbul where ger_bul_code = gerbulcode;
end;
// delimiter ;

select * from gerbul;
desc gerbul;
call insertgerbul("test", 9, 2, "test");
call updategerbul(1, "Test1", 8, 1, "test1");
call deletegerbul(1);
-------------------------------------------- gadaad hel lavlah -----------------------------------------------------

delimiter //

create procedure insertgadaadhelniilavlah(in hcode varchar(3),in gadaad_helnii_lavlah_ner varchar(45)) begin
	insert into gadaadhelniilavlah values(hcode, gadaad_helnii_lavlah_ner);
end;

create procedure updategadaadhelniilavlah(in gadaadhelniilavlahcode varchar(3), in gadaadhelniilavlahner varchar(45)) begin
	update gadaadhelniilavlah set gadaad_helnii_lavlah_ner = gadaadhelniilavlahner  where gadaad_helnii_lavlah_code = gadaadhelniilavlahcode; 
end;

create procedure deletegadaadhelniilavlah(in gadaadhelniilavlahcode varchar(3)) begin
	delete from gadaadhelniilavlah where gadaad_helnii_lavlah_code = gadaadhelniilavlahcode;
end;

// delimiter ;

select * from gadaadhelniilavlah;
desc gadaadhelniilavlah;
call insertgadaadhelniilavlah("tes", "testcountry");
call updategadaadhelniilavlah("tes", "testcoun");
call deletegadaadhelniilavlah("tes");

-------------------------------------------- urChadvarTurul procedures -----------------------------------------------------

delimiter //
create procedure insertUrChadvarTurul(in ulner varchar(45)) begin 
	insert into urChadvarTurul values(null, ulner);
end;

create procedure updateUrChadvarTurul(in uctcode int, in uctner varchar(45)) begin
	update urChadvarTurul set ur_chadvar_turul_ner = uctner where ur_chadvar_turul_code  = uctcode;
end;

create procedure deleteUrChadvarTurul(in uctcode int) begin
	delete from urChadvarTurul where ur_chadvar_turul_code  = uctcode;
end;
// delimiter ;
select * from urChadvarTurul;
desc urChadvarTurul;
call insertUrChadvarTurul('И-спорт');
call updateUrChadvarTurul(11, 'E-sport');
call deleteUrChadvarTurul(11);


-------------------------------------------- urChadvarLavlah procedures -----------------------------------------------------

delimiter //
create procedure insertUrChadvarLavlah(in uChadvar varchar(45), in uctcode int) begin 
	insert into urChadvarLavlah values(null, uChadvar, uctcode);
end;

create procedure updateUrChadvarLavlah(in uclcode int, in uChadvar varchar(45), in uctcode int) begin
	update urChadvarLavlah set ur_chadvar = uChadvar, ur_chadvar_turul_code = uctcode where ur_chadvar_lavlah_code  = uclcode;
end;

create procedure deleteUrChadvarLavlah(in uclcode int) begin
	delete from urChadvarLavlah where ur_chadvar_lavlah_code  = uclcode;
end;
// delimiter ;
select * from urChadvarLavlah;
desc urChadvarLavlah;
call insertUrChadvarLavlah('PUBG тоглох', 4);
call updateUrChadvarLavlah(12, 'Valorant тоглох', 4);
call deleteUrChadvarLavlah(12);


-------------------------------------------- urChadvar procedures -----------------------------------------------------

delimiter //
create procedure insertUrChadvar(in acode int, in uclcode int) begin 
	insert into urChadvar values(null, acode, uclcode);
end;

create procedure updateUrChadvar(in uccode int, in acode int, in uclcode int) begin
	update urChadvar set ajiltan_code = acode, ur_chadvar_lavlah_code = uclcode where ur_chadvar_code = uccode;
end;

create procedure deleteUrChadvar(in uccode int) begin
	delete from urChadvar where ur_chadvar_code = uccode;
end;
// delimiter ;

select * from urChadvar;
desc urChadvar;
call insertUrChadvar(1, 1);
call updateUrChadvar(11, 10, 10);
call deleteUrChadvar(11);

-- ============================================================================================================
  use humanresourcesmanagement;

-------------------------------------- turshlagaLavlah procedures -----------------------------------------------------
delimiter //
create procedure insertturshlagaLavlah(in tlner varchar(45)) begin 
	insert into turshlagaLavlah values(null, tlner);
end;
create procedure updateturshlagaLavlah(in tlcode int, in tlner varchar(45)) begin
	update turshlagaLavlah set turshlaga_lavlah_ner = tlner where turshlaga_lavlah_code = tlcode;
end;
create procedure deleteturshlagaLavlah(in tlcode int) begin
	delete from turshlagaLavlah where turshlaga_lavlah_code = tlcode;
end;
// delimiter ;
select * from turshlagaLavlah;
desc turshlagaLavlah;
call insertturshlagaLavlah('11 жил ажилсан');
call updateturshlagaLavlah(11, '10.5 жил ажилсан');
call deleteturshlagaLavlah(11);

-------------------------------------- turshlaga procedures ---------------------------------------------------------- 
delimiter //
create procedure insertturshlaga(in e_ognoo date, in d_ognoo date, in acode int, in tlcode int) begin 
	insert into turshlaga values(null, e_ognoo, d_ognoo, acode, tlcode);
end;
create procedure updateturshlaga(in tcode int, in e_ognoo date, in d_ognoo date, in acode int, in tlcode int) begin
	update turshlaga set ehleh_ognoo = e_ognoo, duusah_ognoo = d_ognoo, ajiltan_code = acode, turshlaga_lavlah_code = tlcode where turshlaga_code = tcode;
end;
create procedure deleteturshlaga(in tcode int) begin
	delete from turshlaga where turshlaga_code = tcode;
end;
// delimiter ;

select * from turshlaga;
desc turshlaga;
call insertturshlaga('2015-2-2', now(), 10, 10);
call updateturshlaga(11, '2015-2-14', now(), 10, 10);
call deleteturshlaga(11);

-------------------------------------- surgaltLavlah procedures -----------------------------------------------------
delimiter //
create procedure insertsurgaltLavlah(in sner varchar(45)) begin 
	insert into surgaltLavlah values(null, sner);
end;
create procedure updatesurgaltLavlah(in scode int, in sner varchar(45)) begin
	update surgaltLavlah set surgalt_ner = sner where surgalt_code = scode;
end;
create procedure deletesurgaltLavlah(in scode int) begin
	delete from surgaltLavlah where surgalt_code = scode;
end;
// delimiter ;
select * from surgaltLavlah;
desc surgaltLavlah;
call insertsurgaltLavlah('Мэргэжил дээшлүүлэх');
call updatesurgaltLavlah(11, 'Мэргэжил дээшлүүлэх 1');
call deletesurgaltLavlah(11);

-------------------------------------------- surgalt procedures -----------------------------------------------------
delimiter //
create procedure insertsurgalt(in e_ognoo date, in d_ognoo date, in acode int, in slcode int) begin 
	insert into surgalt values(null, e_ognoo, d_ognoo, acode, slcode);
end;
create procedure updatesurgalt(in tcode int, in e_ognoo date, in d_ognoo date, in acode int, in slcode int) begin
	update surgalt set ehleh_ognoo = e_ognoo, duusah_ognoo = d_ognoo, ajiltan_code = acode, surgalt_lavlah_code = slcode where surgalt_code = tcode;
end;
create procedure deletesurgalt(in scode int) begin
	delete from surgalt where surgalt_code = scode;
end;
// delimiter ;

select * from surgalt;
desc surgalt;
call insertsurgalt('2022-11-11', now(), 1, 1);
call updatesurgalt(14, '2022-11-11', now(), 2, 2);
call deletesurgalt(13);


-------------------------------------- heltesLavlah procedures -----------------------------------------------------
delimiter //
create procedure insertheltesLavlah(in hlner varchar(45)) begin 
	insert into heltesLavlah values(null, hlner);
end;
create procedure updateheltesLavlah(in hlcode int, in hlner varchar(45)) begin
	update heltesLavlah set heltes_lavlah_ner = hlner where heltes_lavlah_code = hlcode;
end;
create procedure deleteheltesLavlah(in hlcode int) begin
	delete from heltesLavlah where heltes_lavlah_code = hlcode;
end;
// delimiter ;
select * from heltesLavlah;
desc heltesLavlah;
call insertheltesLavlah('11-р хэлтэс');
call updateheltesLavlah(11, '11-р хэлтэс');
call deleteheltesLavlah(11);

-------------------------------------------- heltes procedures -----------------------------------------------------
delimiter //
create procedure insertheltes(in h_ognoo date, in acode int, in hlcode int) begin 
	insert into heltes values(null, h_ognoo, acode, hlcode);
end;
create procedure updateheltes(in hcode int, in h_ognoo date, in acode int, in hlcode int) begin
	update heltes set heltes_orson_ognoo = h_ognoo, ajiltan_code = acode, heltes_lavlah_code = hlcode where heltes_code = hcode;
end;
create procedure deleteheltes(in hcode int) begin
	delete from heltes where heltes_code = hcode;
end;
// delimiter ;

select * from heltes;
desc heltes;
call insertheltes('2012-2-2',10, 10);
call updateheltes(11, '2012-11-11', 10, 10);
call deleteheltes(11);

-------------------------------------- amraltLavlah procedures -----------------------------------------------------
delimiter //
create procedure insertamraltLavlah(in alner varchar(100)) begin 
	insert into amraltLavlah values(null, alner);
end;
create procedure updateamraltLavlah(in alcode int, in alner varchar(100)) begin
	update amraltLavlah set amralt_lavlah_ner = alner where amralt_lavlah_code = alcode;
end;
create procedure deleteamraltLavlah(in alcode int) begin
	delete from amraltLavlah where amralt_lavlah_code = alcode;
end;
// delimiter ;
select * from amraltLavlah;
desc amraltLavlah;
call insertamraltLavlah('Эмэгтэйчүүдийн баяр');
call updateamraltLavlah(11, 'Эрэгтэйчүүдийн баяр');
call deleteamraltLavlah(11);


-------------------------------------------- amralt procedures -----------------------------------------------------
delimiter //
create procedure insertamralt(in e_ognoo date, in d_ognoo date, in acode int, in alcode int) begin 
	insert into amralt values(null, e_ognoo, d_ognoo, acode, alcode);
end;
create procedure updateamralt(in amcode int, in e_ognoo date, in d_ognoo date, in acode int, in alcode int) begin
	update amralt set ehleh_ognoo = e_ognoo, duusah_ognoo = d_ognoo, ajiltan_code = acode, amralt_lavlah_code = alcode where amralt_code = amcode;
end;
create procedure deleteamralt(in amcode int) begin
	delete from amralt where amralt_code = amcode;
end;
// delimiter ;

select * from amralt;
desc amralt;
call insertamralt('2022-2-2',now(), 10, 10);
call updateamralt(11, '2022-11-11', now(), 10, 10);
call deleteamralt(11);

-- =================================================================================================

-- Боловсрол
delimiter //
create procedure insertBolovsrol(in a_gerchilgeenii_dugaar varchar(16), in a_bolovsrol_ognoo date, in a_ajiltan_code int, in a_bolovsrol_lavlah_code int, in a_bolovsrol_gerchilgee_lavlah_code int) begin
	insert into bolovsrol (bolovsrol_code, gerchilgeenii_dugaar, bolovsrol_ognoo, ajiltan_code, bolovsrol_lavlah_code, bolovsrol_gerchilgee_lavlah_code)
    values(null, a_gerchilgeenii_dugaar, a_bolovsrol_ognoo, a_ajiltan_code,a_bolovsrol_lavlah_code,a_bolovsrol_gerchilgee_lavlah_code);
end;
create procedure updateBolovsrol(in ucode int, in a_ajiltan_code varchar(8)) begin
	update bolovsrol set ajiltan_code = a_ajiltan_code where bolovsrol_code = ucode;
end;
create procedure deleteBolovsrol(in ucode int) begin
	delete from bolovsrol where bolovsrol_code = ucode;
end;
// delimiter ;

select * from bolovsrol;
desc bolovsrol;
call insertBolovsrol('ger dugaar', '2000-1-1', 1,1,1);
call updateBolovsrol(10, 2);
call deleteBolovsrol(10);

-- Боловсрол лавлах
delimiter //
create procedure insertBolovsrolLavlah(in a_bolovsrol_ner varchar(45), in a_bolovsrol_code int) begin
	insert into bolovsrollavlah (bolovsrol_lavlah_code, bolovsrol_ner, bolovsrol_code)
    values(null, a_bolovsrol_ner, a_bolovsrol_code);
end;
create procedure updateBolovsrolLavlah(in ucode int, in a_bolovsrol_ner varchar(45)) begin
	update bolovsrollavlah set bolovsrol_ner = a_bolovsrol_ner where bolovsrol_lavlah_code = ucode;
end;
create procedure deleteBolovsrolLavlah(in ucode int) begin
	delete from bolovsrollavlah where bolovsrol_lavlah_code = ucode;
end;
// delimiter ;

select * from bolovsrollavlah;
desc bolovsrollavlah;
call insertBolovsrolLavlah('hello', 14127);
call updateBolovsrolLavlah(11, 'Hello');
call deleteBolovsrolLavlah(12);

-- Боловсрол гэрчилгээ лавлах
delimiter //
create procedure insertBolovsrolGerchilgeeLavlah(in a_bolovsrol_ner varchar(45)) begin
	insert into bolovsrolgerchilgeelavlah (bolovsrol_gerchilgee_lavlah_code, bolovsrol_ner)
    values(null, a_bolovsrol_ner);
end;
create procedure updateBolovsrolGerchilgeeLavlah(in ucode int, in a_bolovsrol_ner varchar(45)) begin
	update bolovsrolgerchilgeelavlah set bolovsrol_ner = a_bolovsrol_ner where bolovsrol_gerchilgee_lavlah_code = ucode;
end;
create procedure deleteBolovsrolGerchilgeeLavlah(in ucode int) begin
	delete from bolovsrolgerchilgeelavlah where bolovsrol_gerchilgee_lavlah_code = ucode;
end;
// delimiter ;

select * from bolovsrolgerchilgeelavlah;
desc bolovsrolgerchilgeelavlah;
call insertBolovsrolGerchilgeeLavlah('Ugugdliin san');
call updateBolovsrolGerchilgeeLavlah(1, 'Hello');
call deleteBolovsrolGerchilgeeLavlah(10);

---------------------------------------gadaad hel---------------------------------------
delimiter //
create procedure insertgadaadhel(in zereg varchar(45), in olgoson_ognoo date, in ajiltan_code int, in gadaad_helnii_lavlah_code varchar(45)) begin
	insert into gadaadhel values(null, zereg, olgoson_ognoo, ajiltan_code, gadaad_helnii_lavlah_code);
end;
create procedure updategadaadhel(in gadaadhelcode int, in zerg varchar(45), in olgosonognoo date, in ajiltancode int, gadaadhelniilavlahcode varchar(45)) begin
	update gadaadhel set zereg = zerg, olgoson_ognoo = olgosonognoo, ajiltan_code = ajiltancode, gadaad_helnii_lavlah_code = gadaadhelniilavlahcode where gadaad_hel_code = gadaadhelcode;
end;
create procedure deletegadaadhel(in gadaadhelcode int) begin
	delete from gadaadhel where gadaad_hel_code = gadaadhelcode;
end;
// delimiter ;
select * from gadaadhel;
desc gadaadhel;

call insertgadaadhel(6, '2022-11-23', 4, 'MON');
call updategadaadhel(11, '7', '2022-12-31', '4', 'ENG');
call deletegadaadhel(11);