use humanresourcesmanagement;
set global log_bin_trust_function_creators = 1;

-------------------------------------------------- function niit surgaltand hamragdsan udriig oloh ------------------------------------------
drop function if exists function_total_surgalt_day;
delimiter //
create function function_total_surgalt_day(regist varchar(10)) returns int begin
	declare done boolean default 0;
    declare result int default 0;
    declare days int default 0;
    declare cur cursor for 
    select TIMESTAMPDIFF(day, ehleh_ognoo, duusah_ognoo) 
		from surgalt where ajiltan_code = 
			(select ajiltan_code from ajiltan where register_dugaar = regist);
    declare continue handler for sqlstate '02000' set done = 1;
    open cur;
    f_while: while done = 0 do
		set result = result + days;
		fetch cur into days;
    end while f_while;
    close cur;
    return result;
end;
// delimiter ;
set @s = function_total_surgalt_day('ak99068710');
select @s;

select * from surgalt where ajiltan_code = 
	(select ajiltan_code from ajiltan where register_dugaar = 'ak99068710');
select TIMESTAMPDIFF(day, ehleh_ognoo, duusah_ognoo) as surgalt_days 
	from surgalt where ajiltan_code = 
		(select ajiltan_code from ajiltan where register_dugaar = 'ak99068710');
select * from surgalt;
select *from ajiltan;

-------------------------------------------- procedure tuhain ajiltnii niit uramshuulal ---------------------------------------
drop procedure if exists procedure_total_uramshuulal;
delimiter //
create procedure procedure_total_uramshuulal(in register varchar(10), inout result int) begin
	declare done boolean default 0;
    declare days int default 0;
    declare cur cursor for 
    select mungun_dun from uramshuulal where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = register);
    declare continue handler for sqlstate '02000' set done = 1;
    open cur;
    f_while: while done = 0 do
		set result = result + days;
		fetch cur into days;
    end while f_while;
    close cur;
end;
// delimiter ; 

set @result = 0;
call procedure_total_uramshuulal('cf70162111', @result);
select @result;

select * from uramshuulal where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'cf70162111');
select mungun_dun from uramshuulal where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'cf70162111');
select * from uramshuulal;
select * from uramshuulallavlah;
select * from ajiltan;
-- -------------------------------------Ажилтаны жилд нийт амарсан өдрйиг тооцоолох----------------------------
drop procedure if exists procedure_total_amralt;
delimiter //
create procedure procedure_total_amralt(in register varchar(10), inout result int) 
begin
	declare done boolean default 0;
    declare days int default 0;
    declare cur cursor for
		select TIMESTAMPDIFF(day, ehleh_ognoo, duusah_ognoo)
			from amralt where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = register);
    declare continue handler for sqlstate '02000' set done = 1;
    open cur;
    f_while: while done = 0 do
		fetch cur into days;
        set result = result + days;
        fetch cur into days;
    end while f_while;
    close cur;
end;
// delimiter ;
select * from ajiltan;
select * from amralt;
select * from amraltlavlah;

set @result = 0;
call procedure_total_amralt('cf70162111', @result);
SELECT @RESULT;

select * from amralt where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'cf70162111');
select TIMESTAMPDIFF(day, ehleh_ognoo, duusah_ognoo) as amralt_days 
	from amralt where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'cf70162111');




-- -----------------------------------------------Ажилтаны нийт хэлийг тооцоолох--------------------------------------------
select * from gadaadhel;
select * from gadaadhelniilavlah;
drop procedure if exists procedure_total_hel;
delimiter //
create procedure procedure_total_hel(in register varchar(10), inout result int) 
begin
	declare done boolean default 0;
    declare sum int default 0;
    declare cur cursor for
    select ajiltan_code from gadaadhel where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = register);
    declare continue handler for sqlstate '02000' set done = 1;
    open cur;
    f_while: while done = 0 do
        set result = result + 1;
        fetch cur into sum;
        if done = 1 then leave f_while;
        end if;
    end while f_while;
    close cur;
end;
// delimiter ;
select * from ajiltan;
select * from gadaadhel;
select * from gadaadHelniiLavlah;

set @result = 0;
call procedure_total_hel('bg91657099', @result);
select @result as ajiltan_total_hel;
-- bg91657099
select * from gadaadhel where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'bg91657099');
select ajiltan_code, gadaad_helnii_lavlah_code from gadaadhel where ajiltan_code = (select ajiltan_code from ajiltan where register_dugaar = 'bg91657099');