use humanresourcesmanagement;
set global log_bin_trust_function_creators = 1;

-------------------------------------------------- ajiltan hayag --------------------------------------------------------------------
drop view if exists view_ajiltan_geriin_hayag;

delimiter //
create view view_ajiltan_geriin_hayag as
	select a.ajiltan_code, a.ner, hot.hot_aimgiin_ner, d.duureg_sumiin_lavlah_ner, h.horoo_ner, g.geriin_hayag from ajiltan as a
		inner join (select * from geriinhayag) as g
			on a.ajiltan_code = g.ajiltan_code
		inner join (select * from horoolavlah) as h
			on g.horoo_lavlah_code = h.horoo_lavlah_code
		inner join (select * from duuregsumiinlavlah) as d
			on h.duureg_sumiin_lavlah_code = d.duureg_sumiin_lavlah_code
		inner join (select * from hotaimgiinlavlah) as hot
			on d.hot_aimgiin_lavlah_code = hot.hot_aimgiin_lavlah_code;
// delimiter ;

select * from ajiltan;
select * from geriinhayag;
select * from horoolavlah;
select * from duuregsumiinlavlah;
select * from hotaimgiinlavlah;

select * from view_ajiltan_geriin_hayag;

----------------------------------------------------- ajiltan hayag nereer haih ---------------------------------------------
drop function if exists function_ajiltan_ner;

delimiter //
create function function_ajiltan_ner()
returns varchar(45) begin
	if @ajiltan_ner is null then set @ajiltan_ner = '';
    end if;
    return @ajiltan_ner;
end;
// delimiter ;

set @ajiltan_ner = 'Dolgorsuren';
select function_ajiltan_ner();


drop view if exists view_ajiltan_geriin_hayag_find ;
delimiter //
create view view_ajiltan_geriin_hayag_find as
	select a.ajiltan_code, a.ner, hot.hot_aimgiin_ner, d.duureg_sumiin_lavlah_ner, h.horoo_ner, g.geriin_hayag from ajiltan as a
		inner join (select * from geriinhayag) as g
			on a.ajiltan_code = g.ajiltan_code
		inner join (select * from horoolavlah) as h
			on g.horoo_lavlah_code = h.horoo_lavlah_code
		inner join (select * from duuregsumiinlavlah) as d
			on h.duureg_sumiin_lavlah_code = d.duureg_sumiin_lavlah_code
		inner join (select * from hotaimgiinlavlah) as hot
			on d.hot_aimgiin_lavlah_code = hot.hot_aimgiin_lavlah_code
	where a.ner = function_ajiltan_ner();
// delimiter ;

select * from view_ajiltan_geriin_hayag_find;

----------------------------------------------------- ajiltan alban tushaal --------------------------------------
drop view if exists view_ajiltan_alban_tushaal;

delimiter //
create view view_ajiltan_alban_tushaal as
	select a.ovog, a.ner, a.huis, a.utas, a.register_dugaar, albalav.alban_tushaal_ner from ajiltan as a
		inner join (select alban_tushaal_code, ajiltan_code, alban_tushaal_lavlah_code from albantushaal) as alba
			on a.ajiltan_code = alba.ajiltan_code
		inner join (select * from albantushaallavlah) as albalav
			on alba.alban_tushaal_lavlah_code = albalav.alban_tushaal_lavlah_code;
// delimiter ;

select * from ajiltan;
select * from albantushaal;
select * from albantushaallavlah;

select * from view_ajiltan_alban_tushaal;

-------------------------------------------------- ajiltan alban tushaaliin ner -----------------------------------
drop function if exists function_alba_ner;

delimiter //
create function function_alba_ner()
returns varchar(45) begin
	if @alba_ner is null then set @alba_ner = '';
    end if;
    return @alba_ner;
end;
// delimiter ;

set @alba_ner = 'Захирал';
select function_alba_ner();

drop view if exists view_ajiltan_alban_tushaal_find;
delimiter //
create view view_ajiltan_alban_tushaal_find as
	select a.ovog, a.ner, a.huis, a.utas, a.register_dugaar, albalav.alban_tushaal_ner from ajiltan as a
		inner join (select alban_tushaal_code, ajiltan_code, alban_tushaal_lavlah_code from albantushaal) as alba
			on a.ajiltan_code = alba.ajiltan_code
		inner join (select * from albantushaallavlah) as albalav
			on alba.alban_tushaal_lavlah_code = albalav.alban_tushaal_lavlah_code
	where albalav.alban_tushaal_ner = function_alba_ner();
// delimiter ;

select * from view_ajiltan_alban_tushaal_find;